import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:just_audio/just_audio.dart';

import '../../../core/constants/app_constants.dart';
import '../../playlist/bloc/playlist_bloc.dart';
import '../../playlist/bloc/playlist_event.dart';
import 'audio_event.dart';
import 'audio_state.dart';

class AudioBloc extends Bloc<AudioEvent, AudioState> {
  AudioBloc({PlaylistBloc? playlistBloc})
      : _playlistBloc = playlistBloc,
        super(const AudioInitial()) {
    on<AudioPlayEvent>               (_onPlay);
    on<AudioPauseEvent>              (_onPause);
    on<AudioResumeEvent>             (_onResume);
    on<AudioSeekEvent>               (_onSeek);
    on<AudioSkipForwardEvent>        (_onSkipForward);
    on<AudioSkipBackwardEvent>       (_onSkipBackward);
    on<AudioNextTrackEvent>          (_onNext);
    on<AudioPrevTrackEvent>          (_onPrev);
    on<AudioSetVolumeEvent>          (_onVolume);
    on<AudioToggleRepeatEvent>       (_onRepeat);
    on<AudioToggleShuffleEvent>      (_onShuffle);
    on<AudioStopEvent>               (_onStop);
    on<AudioPositionUpdatedEvent>    (_onPosition);
    on<AudioDurationUpdatedEvent>    (_onDuration);
    on<AudioPlayingStateChangedEvent>(_onPlayingState);
    on<AudioTrackCompletedEvent>     (_onTrackCompleted);

    _subscribeToPlayer();
  }

  final AudioPlayer    _player = AudioPlayer();
  final PlaylistBloc?  _playlistBloc;
  final Random         _random = Random();

  // Tracks which indices have been played during the current shuffle session
  final Set<int> _shufflePlayed = {};

  StreamSubscription<Duration>?    _posSub;
  StreamSubscription<Duration?>?   _durSub;
  StreamSubscription<bool>?        _playSub;
  StreamSubscription<PlayerState>? _stateSub;

  void _subscribeToPlayer() {
    _posSub  = _player.positionStream.listen(
        (pos) => add(AudioPositionUpdatedEvent(pos)));
    _durSub  = _player.durationStream.listen(
        (dur) => add(AudioDurationUpdatedEvent(dur)));
    _playSub = _player.playingStream.listen(
        (playing) => add(AudioPlayingStateChangedEvent(isPlaying: playing)));

    // Auto-advance when a track finishes naturally
    _stateSub = _player.playerStateStream.listen((ps) {
      if (ps.processingState == ProcessingState.completed) {
        add(const AudioTrackCompletedEvent());
      }
    });
  }

  // ── Event handlers ───────────────────────────────────────

Future<void> _onPlay(
  AudioPlayEvent event,
  Emitter<AudioState> emit,
) async {
  emit(const AudioLoading());
  try {
    final item  = event.item;
    final queue = event.playlist.isEmpty ? [item] : event.playlist;
    final index = queue.indexWhere((e) => e.id == item.id).clamp(0, queue.length - 1);

    _persistCurrentPosition();

    // Load the source and AWAIT the duration before emitting AudioReady
    final Duration? loadedDuration;
    if (item.isNetwork) {
      loadedDuration = await _player.setUrl(item.path);
    } else {
      loadedDuration = await _player.setFilePath(item.path);
    }

    if (item.lastPositionSeconds > 0) {
      await _player.seek(item.lastPosition);
    }

    _shufflePlayed.clear();
    _shufflePlayed.add(index);

    // Emit AudioReady BEFORE calling play() so the position/duration
    // stream events that follow have a valid AudioReady state to update.
    emit(AudioReady(
      currentItem: item,
      isPlaying:   false,           // will be set to true by the stream event
      duration:    loadedDuration ?? Duration.zero,
      playlist:    queue,
      queueIndex:  index,
    ));

    await _player.play();
  } catch (e) {
    emit(AudioError('Failed to play: ${e.toString()}'));
  }
}

  Future<void> _onPause(AudioPauseEvent _, Emitter<AudioState> emit) async {
    await _player.pause();
    if (state is AudioReady) {
      emit((state as AudioReady).copyWith(isPlaying: false));
    }
  }

  Future<void> _onResume(AudioResumeEvent _, Emitter<AudioState> emit) async {
    await _player.play();
    if (state is AudioReady) {
      emit((state as AudioReady).copyWith(isPlaying: true));
    }
  }

  Future<void> _onSeek(AudioSeekEvent event, Emitter<AudioState> emit) async {
    await _player.seek(event.position);
    if (state is AudioReady) {
      emit((state as AudioReady).copyWith(position: event.position));
    }
  }

  Future<void> _onSkipForward(AudioSkipForwardEvent _, Emitter<AudioState> emit) async {
    if (state is! AudioReady) return;
    final s       = state as AudioReady;
    final pos     = s.position + AppConstants.seekForward;
    final clamped = pos > s.duration ? s.duration : pos;
    await _player.seek(clamped);
    emit(s.copyWith(position: clamped));
  }

  Future<void> _onSkipBackward(AudioSkipBackwardEvent _, Emitter<AudioState> emit) async {
    if (state is! AudioReady) return;
    final s       = state as AudioReady;
    final pos     = s.position - AppConstants.seekBackward;
    final clamped = pos.isNegative ? Duration.zero : pos;
    await _player.seek(clamped);
    emit(s.copyWith(position: clamped));
  }

  Future<void> _onNext(AudioNextTrackEvent _, Emitter<AudioState> emit) async {
    if (state is! AudioReady) return;
    final s = state as AudioReady;
    _persistCurrentPosition();
    final nextIndex = _nextIndex(s);
    if (nextIndex == null) return;
    add(AudioPlayEvent(s.playlist[nextIndex], playlist: s.playlist));
  }

  Future<void> _onPrev(AudioPrevTrackEvent _, Emitter<AudioState> emit) async {
    if (state is! AudioReady) return;
    final s = state as AudioReady;
    if (s.position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      emit(s.copyWith(position: Duration.zero));
      return;
    }
    if (!s.hasPrev) return;
    _persistCurrentPosition();
    add(AudioPlayEvent(s.playlist[s.queueIndex - 1], playlist: s.playlist));
  }

  Future<void> _onVolume(AudioSetVolumeEvent event, Emitter<AudioState> emit) async {
    await _player.setVolume(event.volume.clamp(0.0, 1.0));
    if (state is AudioReady) {
      emit((state as AudioReady).copyWith(volume: event.volume));
    }
  }

  void _onRepeat(AudioToggleRepeatEvent _, Emitter<AudioState> emit) {
    if (state is! AudioReady) return;
    final s    = state as AudioReady;
    final next = RepeatMode.values[(s.repeatMode.index + 1) % RepeatMode.values.length];
    _player.setLoopMode(_loopMode(next));
    emit(s.copyWith(repeatMode: next));
  }

  void _onShuffle(AudioToggleShuffleEvent _, Emitter<AudioState> emit) {
    if (state is! AudioReady) return;
    final s          = state as AudioReady;
    final newShuffle = !s.isShuffle;
    if (newShuffle) {
      _shufflePlayed.clear();
      _shufflePlayed.add(s.queueIndex);
    }
    emit(s.copyWith(isShuffle: newShuffle));
  }

  Future<void> _onStop(AudioStopEvent _, Emitter<AudioState> emit) async {
    _persistCurrentPosition();
    await _player.stop();
    emit(const AudioInitial());
  }

  // ── Auto-advance: fires when the player reaches the natural end ──

  Future<void> _onTrackCompleted(
    AudioTrackCompletedEvent _,
    Emitter<AudioState> emit,
  ) async {
    if (state is! AudioReady) return;
    final s = state as AudioReady;

    if (s.repeatMode == RepeatMode.one) {
      await _player.seek(Duration.zero);
      await _player.play();
      return;
    }

    _persistCurrentPosition();
    final nextIndex = _nextIndex(s);

    if (nextIndex == null) {
      emit(s.copyWith(isPlaying: false, position: s.duration));
      return;
    }

    add(AudioPlayEvent(s.playlist[nextIndex], playlist: s.playlist));
  }

  // ── Internal stream events ───────────────────────────────

  void _onPosition(AudioPositionUpdatedEvent event, Emitter<AudioState> emit) {
  if (state is AudioReady) {
    emit((state as AudioReady).copyWith(position: event.position));
  }
  // Silently ignore during AudioLoading — no needle to move yet.
}

  void _onDuration(AudioDurationUpdatedEvent event, Emitter<AudioState> emit) {
  if (event.duration == null) return;
  if (state is AudioReady) {
    emit((state as AudioReady).copyWith(duration: event.duration));
  }
  // If we're still in AudioLoading the duration will be set by _onPlay's
  // loadedDuration return value — nothing to do here.
}

  void _onPlayingState(AudioPlayingStateChangedEvent event, Emitter<AudioState> emit) {
  if (state is AudioReady) {
    emit((state as AudioReady).copyWith(isPlaying: event.isPlaying));
  }
}

  // ── Shuffle / next-index logic ───────────────────────────

  int? _nextIndex(AudioReady s) {
    final queue = s.playlist;
    if (queue.isEmpty) return null;

    if (s.isShuffle) {
      final remaining = List.generate(queue.length, (i) => i)
          .where((i) => !_shufflePlayed.contains(i))
          .toList();

      if (remaining.isEmpty) {
        if (s.repeatMode == RepeatMode.all) {
          _shufflePlayed.clear();
          final next = _random.nextInt(queue.length);
          _shufflePlayed.add(next);
          return next;
        }
        return null;
      }

      final next = remaining[_random.nextInt(remaining.length)];
      _shufflePlayed.add(next);
      return next;
    }

    // Linear
    if (s.queueIndex < queue.length - 1) return s.queueIndex + 1;
    if (s.repeatMode == RepeatMode.all)  return 0;
    return null;
  }

  // ── Position persistence ─────────────────────────────────

  void _persistCurrentPosition() {
    if (state is! AudioReady) return;
    final s          = state as AudioReady;
    final posSeconds = s.position.inSeconds;
    if (posSeconds < 5) return;
    _playlistBloc?.add(
      PlaylistUpdatePositionEvent(s.currentItem.id, posSeconds),
    );
    debugPrint('💾 Saved ${posSeconds}s for "${s.currentItem.title}"');
  }

  LoopMode _loopMode(RepeatMode mode) {
    switch (mode) {
      case RepeatMode.none: return LoopMode.off;
      case RepeatMode.one:  return LoopMode.one;
      case RepeatMode.all:  return LoopMode.off; // repeat-all handled manually
    }
  }

  @override
  Future<void> close() async {
    _persistCurrentPosition();
    await _posSub?.cancel();
    await _durSub?.cancel();
    await _playSub?.cancel();
    await _stateSub?.cancel();
    await _player.dispose();
    return super.close();
  }
}
