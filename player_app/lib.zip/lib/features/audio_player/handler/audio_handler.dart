import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';
import '../../playlist/domain/entities/media_item.dart' as app;

class AppAudioHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer player = AudioPlayer();

  // Store subscriptions so we can cancel them properly
  StreamSubscription? _playbackEventSub;
  StreamSubscription? _durationSub;
  StreamSubscription? _playerStateSub;

  AppAudioHandler() {
    // FIX: Use listen() + manual add() instead of pipe()
    // pipe() uses addStream() which LOCKS the playbackState sink,
    // causing "Bad state: cannot add while addStream is active" when
    // super.stop() also tries to add() to the same sink.
    _playbackEventSub = player.playbackEventStream.listen((event) {
      playbackState.add(_transformEvent(event));
    });

    _durationSub = player.durationStream.listen((dur) {
      final current = mediaItem.value;
      if (current != null && dur != null) {
        mediaItem.add(current.copyWith(duration: dur));
      }
    });

    _playerStateSub = player.playerStateStream.listen((ps) {
      if (ps.processingState == ProcessingState.completed) {
        playbackState.add(playbackState.value.copyWith(
          processingState: AudioProcessingState.completed,
        ));
      }
    });
  }

  Future<Duration?> loadAndPlay(app.MediaItem item) async {
    mediaItem.add(MediaItem(
      id:     item.path,
      title:  item.title,
      artist: item.artist ?? 'Unknown artist',
      album:  '',
      artUri: _artUri(item.albumArt),
    ));

    final Duration? duration;
    if (item.isNetwork) {
      duration = await player.setUrl(item.path);
    } else {
      duration = await player.setFilePath(item.path);
    }

    await player.play();
    return duration;
  }

  Uri? _artUri(String? art) {
    if (art == null) return null;
    if (art.startsWith('http')) return Uri.tryParse(art);
    return Uri.file(art);
  }

  @override
  Future<void> play() => player.play();

  @override
  Future<void> pause() => player.pause();

  @override
  Future<void> stop() async {
    await player.stop();
    // FIX: super.stop() safely calls playbackState.add() because
    // we are no longer using pipe()/addStream() above.
    await super.stop();
  }

  @override
  Future<void> seek(Duration pos) => player.seek(pos);

  @override
  Future<void> skipToNext() async {}

  @override
  Future<void> skipToPrevious() async {}

  @override
  Future<void> onTaskRemoved() async {
    await stop();
    await super.onTaskRemoved();
  }

  // FIX: Cancel all subscriptions to avoid memory leaks and
  // zombie listeners after the handler is destroyed.
  Future<void> dispose() async {
    await _playbackEventSub?.cancel();
    await _durationSub?.cancel();
    await _playerStateSub?.cancel();
    await player.dispose();
  }

  PlaybackState _transformEvent(PlaybackEvent event) {
    return PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        if (player.playing) MediaControl.pause else MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      systemActions: const {
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
        MediaAction.skipToPrevious,
        MediaAction.skipToNext,
      },
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle:      AudioProcessingState.idle,
        ProcessingState.loading:   AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready:     AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[player.processingState]!,
      playing:          player.playing,
      updatePosition:   player.position,
      bufferedPosition: player.bufferedPosition,
      speed:            player.speed,
      queueIndex:       event.currentIndex,
    );
  }
}